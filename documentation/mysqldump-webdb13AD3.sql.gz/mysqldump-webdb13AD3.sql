-- MySQL dump 10.13  Distrib 5.1.61, for redhat-linux-gnu (x86_64)
--
-- Host: localhost    Database: webdb13AD3
-- ------------------------------------------------------
-- Server version	5.1.61

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categories` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(60) NOT NULL,
  `description` longtext NOT NULL,
  `status` int(2) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `category_name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` VALUES (7,'Software','vragen over onze software',0),(8,'Hardware','Vragen over onze hardware',1),(9,'Bezems','Vragen over onze bezems',0),(10,'Filosofie','Existentiele kwesties in een digitaal tijdperk',1);
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `credits`
--

DROP TABLE IF EXISTS `credits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `credits` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned NOT NULL,
  `value` int(4) NOT NULL,
  `reply_id` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `reply_id` (`reply_id`),
  KEY `user_id` (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `credits`
--

LOCK TABLES `credits` WRITE;
/*!40000 ALTER TABLE `credits` DISABLE KEYS */;
/*!40000 ALTER TABLE `credits` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `replies`
--

DROP TABLE IF EXISTS `replies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `replies` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned NOT NULL,
  `thread_id` int(11) unsigned NOT NULL,
  `ts_created` int(13) NOT NULL,
  `ts_modified` int(13) DEFAULT NULL,
  `title` text NOT NULL,
  `content` longtext NOT NULL,
  `visibility` int(1) NOT NULL DEFAULT '0',
  `credits` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `thread_id` (`thread_id`),
  KEY `ts_created` (`ts_created`),
  KEY `credits` (`credits`),
  KEY `user_id` (`user_id`),
  FULLTEXT KEY `fullcontent` (`title`,`content`)
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `replies`
--

LOCK TABLES `replies` WRITE;
/*!40000 ALTER TABLE `replies` DISABLE KEYS */;
INSERT INTO `replies` VALUES (9,12,12,1359724523,1359724523,'Alleen een admin kan dat','Het systeem is zp gebouwd dat alleen een administrator bij het gebruikersoverzicht kan komen.\r\nIn dit overzicht kan diegene u dan instellen als administrator.',1,0),(10,13,13,1359725322,1359725322,'Windows','Werk je toevallig op Windows? Dan kun je ook minder makkelijk in de command-line git kijken wat er aan de hand is.\r\nHeb je wel een shell tot je beschikking: doe dan even git -status en post hier je output. Misschien kan ik dan helpen\r\n',1,0),(11,13,14,1359726427,1359726427,'Marx','V*8ze V88ele MARXIST!!! eins!!!\r\n\r\nSpam als deze, moet je natuurlijk kunnen verwijderen.\r\nOf wacht: we gooien gewoon die hele tot Godwins uitnodigende thread weg.',1,0),(12,12,13,1359726588,1359726588,'Windows','Zit inderdaad op windows, maar kan niet kopieren uit mijn Gitbash. Er staat: Not currently in any branch. Enig idee?',1,0),(13,13,17,1359729071,1359729071,'Zo\'n heksending','Ik zou voor zo\'n heksenbezem gaan. Die kan ook vliegen. Da\'s handig.\r\nWapperende haren op een houten bezem. Dat zijn de betere haren.',1,0);
/*!40000 ALTER TABLE `replies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `threads`
--

DROP TABLE IF EXISTS `threads`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `threads` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned NOT NULL,
  `category_id` int(11) unsigned NOT NULL,
  `ts_created` int(13) NOT NULL,
  `ts_modified` int(13) DEFAULT NULL,
  `title` text NOT NULL,
  `content` longtext NOT NULL,
  `status` int(2) NOT NULL DEFAULT '0',
  `open` int(1) unsigned NOT NULL DEFAULT '1',
  `answer_id` int(11) unsigned DEFAULT NULL,
  `views` int(13) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `category_id` (`category_id`),
  KEY `ts_created` (`ts_created`),
  KEY `user_id` (`user_id`),
  KEY `views` (`views`),
  FULLTEXT KEY `fullcontent` (`title`,`content`)
) ENGINE=MyISAM AUTO_INCREMENT=21 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `threads`
--

LOCK TABLES `threads` WRITE;
/*!40000 ALTER TABLE `threads` DISABLE KEYS */;
INSERT INTO `threads` VALUES (12,14,7,1359724400,1359732565,'admin-gebruiker','Hoe kan ik admin-gebruiker worden?',1,1,9,7),(13,12,7,1359724568,1359738167,'Netbeans & Git','Mijn Git-repo is stuk. Kan niet meer pushen of pullen, ik werk met Netbeans, iemand een idee?',1,1,10,13),(14,12,10,1359724660,1359743880,'Marxisme vs. Rawlsiaans liberalisme','Kan iemand mij de exacte verschillen uitleggen tussen het gedachtegoed van Karl Marx en Rawls?',1,1,NULL,9),(15,12,10,1359726371,1359747818,'Descartiaans dualisme','Waarom maakte Descartes precies onderscheidt tussen lichaam en geest, iets wat ook wel het Descartiaans dualisme wordt genoemd?',0,1,NULL,5),(17,13,9,1359729015,1359744285,'Welke type','Er zijn bezems met haren van plastic, en met haren van twijgjes. Welke zou beter zijn?\r\nWikipedia zegt: Het materiaal van de bezem varieert: de oude bezems bestonden uit bijeengebonden takkenbossen, rond een stok (steel). Dit soort bezems slijt snel, vandaar de uitdrukking \"nieuwe bezems vegen schoon\". Kenners voegen daaraan toe: \"maar oude bezems kennen alle hoekjes\". Door de slijtage wordt de onderkant van de bezem namelijk vlak, waardoor men tot in alle hoekjes kan vegen.\r\n\r\nVoor buitenbezems worden takken van de berk of de wortels van het Pijpenstrootje gebruikt, voor binnen gebruikte men vroeger het fijnere huttentut.',1,1,NULL,5),(18,13,10,1359729654,1359744284,'Samson, reacties in filosofie','Samsom een Hercules-figuur, ontleende zijn kracht aan zijn haren. Toen zijn weelderige haardos werd afgeknipt, verloor hij al zijn macht.\r\n\r\nKeert dat thema wel eens terug in de hedendaagse filosofie? Als ik naar zo n Sloterdijk kijk...',1,0,NULL,9),(19,13,9,1359730668,1359747800,'Bezemsteel','Is het legaal een bezemsteel te stelen?',0,1,NULL,10),(20,14,8,1359739326,1359742614,'asdfasdf','asdfasdaf',1,1,NULL,3);
/*!40000 ALTER TABLE `threads` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `pass` varchar(64) NOT NULL,
  `email` varchar(100) NOT NULL,
  `ts_registered` int(13) NOT NULL,
  `role` int(2) NOT NULL DEFAULT '0',
  `firstname` varchar(60) DEFAULT NULL,
  `lastname` varchar(60) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (10,'e7996bddd7962fd2f46a5392dc887827','mail@webdb.science.uva.nl',1359723309,1,'Alex','Dmin'),(12,'14280a2b6af4e5a39044c9580c414e01','frank@accode.nl',1359724231,1,'Frank','van Luijn'),(13,'1fc1492ab17b1352c34ce3b19da11a28','r.creyghton@gmail.com',1359724291,1,'Ramon','Creyghton'),(14,'cdc3ac718297dcf01351c1256fea133c','s.ah@live.nl',1359724315,1,'Shafiq','Ahmadi');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2013-02-01 20:44:20
