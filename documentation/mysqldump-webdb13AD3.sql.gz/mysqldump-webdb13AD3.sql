-- MySQL dump 10.13  Distrib 5.1.61, for redhat-linux-gnu (x86_64)
--
-- Host: localhost    Database: webdb13AD3
-- ------------------------------------------------------
-- Server version	5.1.61

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categories` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(60) NOT NULL,
  `description` longtext NOT NULL,
  `status` int(2) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `category_name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` VALUES (1,'Test categorie 2','Een categorie met test-posts',1),(2,'Test categorie 3','Hier komt een omschrijving',1),(5,'Test categorie','Bijvoorbeeld: producttype',0),(6,'Bezems','Alles over uw bezem',0);
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `credits`
--

DROP TABLE IF EXISTS `credits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `credits` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned NOT NULL,
  `value` int(4) NOT NULL,
  `reply_id` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `reply_id` (`reply_id`),
  KEY `user_id` (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `credits`
--

LOCK TABLES `credits` WRITE;
/*!40000 ALTER TABLE `credits` DISABLE KEYS */;
INSERT INTO `credits` VALUES (1,3,1,1),(2,2,1,1);
/*!40000 ALTER TABLE `credits` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `replies`
--

DROP TABLE IF EXISTS `replies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `replies` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned NOT NULL,
  `thread_id` int(11) unsigned NOT NULL,
  `ts_created` int(13) NOT NULL,
  `ts_modified` int(13) DEFAULT NULL,
  `title` text NOT NULL,
  `content` longtext NOT NULL,
  `visibility` int(1) NOT NULL DEFAULT '0',
  `credits` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `thread_id` (`thread_id`),
  KEY `ts_created` (`ts_created`),
  KEY `credits` (`credits`),
  KEY `user_id` (`user_id`),
  FULLTEXT KEY `fullcontent` (`title`,`content`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `replies`
--

LOCK TABLES `replies` WRITE;
/*!40000 ALTER TABLE `replies` DISABLE KEYS */;
INSERT INTO `replies` VALUES (1,1,2,0,0,'Testreply','Inhoud van reply door Ramon op Frank...',0,0),(2,1,1,1358855073,1358855073,'Testreply van Ramon op Frank\'s post.','Inhoud van testreply',1,0),(3,2,2,1358855107,1358855107,'Titeltje maar weer','INhoud van testreply van frank op ramon',1,0),(4,1,1,1358855073,NULL,'Ramon reageert nog een keer, voor de vorm.','Nog maar eens een reactie van ramon.',1,0),(5,1,3,1358855080,NULL,'Testreply van Ramon op Shafiq\'s post','Inhoud van testreply',1,0),(6,1,6,1359624513,1359624513,'Testantwoord','Dit antwoord is zoekbaar zonder dat je het merkt.',1,0),(7,8,9,1359661449,1359661449,'Antwoord op bezemvraag','Ik zou een stofzuiger of bladblazer aanschaffen...',1,0),(8,1,10,1359713250,1359713250,'Een grasmaaier heeft scherpe messen.','Eerlijk gezegd, Ramon, denk ik niet dat je haren vergoed gaat krijgen als je ze zelf vakkundig hebt doorgeknipt met een goed geslepen grasmaaier.\r\nHet is altijd verstandiger je grasmaaier met je vingers schoon te maken, dat vind het staal prettiger.',1,0);
/*!40000 ALTER TABLE `replies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `threads`
--

DROP TABLE IF EXISTS `threads`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `threads` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned NOT NULL,
  `category_id` int(11) unsigned NOT NULL,
  `ts_created` int(13) NOT NULL,
  `ts_modified` int(13) DEFAULT NULL,
  `title` text NOT NULL,
  `content` longtext NOT NULL,
  `status` int(2) NOT NULL DEFAULT '0',
  `open` int(1) unsigned NOT NULL DEFAULT '1',
  `answer_id` int(11) unsigned DEFAULT NULL,
  `views` int(13) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `category_id` (`category_id`),
  KEY `ts_created` (`ts_created`),
  KEY `user_id` (`user_id`),
  KEY `views` (`views`),
  FULLTEXT KEY `fullcontent` (`title`,`content`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `threads`
--

LOCK TABLES `threads` WRITE;
/*!40000 ALTER TABLE `threads` DISABLE KEYS */;
INSERT INTO `threads` VALUES (1,2,2,1358721965,1359712657,'Testpost 1 by Frank','Bladibaldibal',0,1,NULL,2),(2,1,2,1358721965,1359651500,'Tweede testpost door ramon','Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas imperdiet consequat tristique. Curabitur tincidunt turpis vel odio semper lacinia. Pellentesque venenatis eleifend erat, eget imperdiet magna convallis a. Sed eu lectus sapien. Integer adipiscing, enim a malesuada vulputate, ipsum mi iaculis turpis, vitae accumsan enim massa quis quam. Quisque aliquam iaculis condimentum. Nulla facilisi. Ut convallis pulvinar porttitor. Nunc nec nibh tellus. Mauris in ligula eget felis placerat eleifend at et ipsum. Fusce bibendum bibendum egestas. Morbi eu mi augue, non auctor velit. Proin at tincidunt neque.\r\nSed ultricies varius interdum. In hac habitasse platea dictumst. Phasellus ut nunc in ante vehicula dignissim ac ut leo. Pellentesque lacinia condimentum orci at molestie. Quisque non dui odio. Proin a magna et ligula sagittis pretium. Aliquam faucibus consectetur leo vitae tincidunt. Nullam ut magna nec erat aliquam sollicitudin ac sed dolor. Phasellus porta, dui sed auctor sagittis, orci justo dignissim massa, in cursus neque risus in magna. Sed dolor nibh, iaculis a condimentum sit amet, eleifend non magna. Pellentesque sit amet turpis nulla. Nunc mi sem, pulvinar a dignissim non, condimentum eget sapien. Ut in mauris egestas ante sodales lacinia consectetur in libero. Aliquam aliquet fermentum pretium. ',1,1,1,2),(3,3,1,1358974858,1359667006,'En ook s.ah mag een testpost plaatsen.','Testinhoud',0,1,5,4),(5,1,2,1359551632,1359652976,'Hoe kun je op deze site zoeken?','Door gebruik te maken van de zoekbalk bovenaan.',1,1,NULL,6),(6,1,1,1359555051,1359712655,'Hoe kun je op deze site zoeken?','Dat is de vraag',0,1,NULL,4),(7,1,5,1359635693,1359712659,'Testje','Deze vraag zou standaard verborgen moeten zijn.',0,0,NULL,1),(10,1,6,1359712788,1359713250,'De haren vallen uit','Ik kocht een jaar geleden een bezem met platic  haren bij u. Nu vallen ze in hoog tempo uit. Kan het ermee te maken hebben dat ik er mijn grasmaaimachine mee schoonmaak terwijl die aanstaat?',1,1,NULL,3),(8,1,2,1359635786,1359712661,'OPen','Deze zou standaard open moeten zijn.',0,0,NULL,1),(9,1,6,1359660970,1359712952,'Bezemtype','Wat veegt beter? Een bezem met natuurlijke haren of een bezem met plastic haren? Wie o wie helpt mij?\n\n\n Bijgewerkt op 31-01-2013:\n -----------------------------------\nTest van edit. Waarom niet gewoon de tekst zelf bewerken?',1,1,NULL,22),(11,1,6,1359712910,1359712974,'Kleur','In mijn beleving is zijn die bezems met roze haren toch wel een beetje raar. Maar ze vegen beter, lijkt wel. Maken jullie stiekem de beste bezems het lelijkst?',1,1,NULL,2);
/*!40000 ALTER TABLE `threads` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `pass` varchar(64) NOT NULL,
  `email` varchar(100) NOT NULL,
  `ts_registered` int(13) NOT NULL,
  `role` int(2) NOT NULL DEFAULT '0',
  `firstname` varchar(60) DEFAULT NULL,
  `lastname` varchar(60) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (3,'6a204bd89f3c8348afd5c77c717a097a','s.ah@live.nl',1359624417,1,'Shafiq','Ahmadi'),(4,'6a204bd89f3c8348afd5c77c717a097a','ram.con@gmail.com',1358938435,-1,'Testuser','Achternaampje'),(1,'e8a631b6bc88275088a43625f7f9cc7c','r.creyghton@gmail.com',1359466523,1,'Ramon','Creyghton'),(2,'6a204bd89f3c8348afd5c77c717a097a','frank@accode.nl',1358942213,1,'Frank','van Luijn'),(5,'6a204bd89f3c8348afd5c77c717a097a','m.c.vandebovenkamp@uva.nl',1358943779,0,'Martijn','van de Bovenkamp'),(8,'1c106ec53b0ec5183c2273f3b31da6b8','88marjolijn@live.nl',1359660081,1,'Marjolijn','Feddema'),(9,'850ed26ddd1f6978447a1bab91009cf8','mail@webdb.science.uva.nl',1359717737,1,'Beoordeling','WebDB13AD3');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2013-02-01 13:56:11
